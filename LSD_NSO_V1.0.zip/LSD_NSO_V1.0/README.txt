========================================================================
             NSO GameCube Driver (BETA v1.0)
                Created by LoveSikDogs
========================================================================

Thank you for testing the NSO GameCube Controller Driver! 
This tool allows you to use your Nintendo Switch Online GameCube 
controller on PC with full analog trigger support and automatic 
configuration for Dolphin Emulator.

------------------------------------------------------------------------
 INSTRUCTIONS
------------------------------------------------------------------------
1. Run "LoveSikDogs_NSO_Driver.exe".
2. If this is your first time, it may ask to install the "ViGEmBus" 
   driver. This is required to create the virtual Xbox controller. 
   Click Yes to download and install it.
3. Once the driver is installed, restart the application.
4. Hold the SYNC button on your controller until the LED turns solid.
5. The application will minimize to the System Tray (near your clock).

------------------------------------------------------------------------
 DOLPHIN EMULATOR SETUP
------------------------------------------------------------------------
This driver automatically installs a controller profile for you!

1. Open Dolphin Emulator.
2. Go to "Controllers".
3. Under "Standard Controller" for Port 1, click "Configure".
4. In the "Profile" dropdown at the top right, select:
   >> "lsd_nso"
5. Click "Load".
6. You are ready to play!

*Troubleshooting:* If the profile does not appear, right-click the 
Purple GameCube icon in your system tray and select 
"Save Dolphin Profile..." to save it manually.

------------------------------------------------------------------------
 BETA NOTICE & FEEDBACK
------------------------------------------------------------------------
This software is currently in BETA. While it has been tested for 
stability, bugs may occur.

Rumble support is currently unavailable. 

Please report any crashes, connection issues, or weird behavior to:
lovesikdogg@gmail.com

------------------------------------------------------------------------
 CREDITS
------------------------------------------------------------------------
Powered by ViGEmBus (Virtual Gamepad Emulation Bus).
Created by Nefarius software solutions.
https://github.com/nefarius/ViGEmBus

NSO Driver Logic & UI by LoveSikDog.